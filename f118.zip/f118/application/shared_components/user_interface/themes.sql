prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 118
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>9474325786859224
,p_default_application_id=>118
,p_default_id_offset=>0
,p_default_owner=>'ONTOOR'
);
wwv_flow_api.create_theme(
 p_id=>wwv_flow_api.id(16613608479871747)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_ui_type_name=>'DESKTOP'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_is_locked=>false
,p_default_page_template=>wwv_flow_api.id(16512011201871662)
,p_default_dialog_template=>wwv_flow_api.id(16507701778871659)
,p_error_template=>wwv_flow_api.id(16499804692871650)
,p_printer_friendly_template=>wwv_flow_api.id(16512011201871662)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_api.id(16499804692871650)
,p_default_button_template=>wwv_flow_api.id(16610640803871734)
,p_default_region_template=>wwv_flow_api.id(16548100513871687)
,p_default_chart_template=>wwv_flow_api.id(16548100513871687)
,p_default_form_template=>wwv_flow_api.id(16548100513871687)
,p_default_reportr_template=>wwv_flow_api.id(16548100513871687)
,p_default_tabform_template=>wwv_flow_api.id(16548100513871687)
,p_default_wizard_template=>wwv_flow_api.id(16548100513871687)
,p_default_menur_template=>wwv_flow_api.id(16557527404871694)
,p_default_listr_template=>wwv_flow_api.id(16548100513871687)
,p_default_irr_template=>wwv_flow_api.id(16546255955871686)
,p_default_report_template=>wwv_flow_api.id(16577088233871707)
,p_default_label_template=>wwv_flow_api.id(16609547294871732)
,p_default_menu_template=>wwv_flow_api.id(16612045204871735)
,p_default_calendar_template=>wwv_flow_api.id(16612130835871737)
,p_default_list_template=>wwv_flow_api.id(16593476094871719)
,p_default_nav_list_template=>wwv_flow_api.id(16605237070871728)
,p_default_top_nav_list_temp=>wwv_flow_api.id(16605237070871728)
,p_default_side_nav_list_temp=>wwv_flow_api.id(16599857582871724)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_api.id(16520786734871670)
,p_default_dialogr_template=>wwv_flow_api.id(16519706650871669)
,p_default_option_label=>wwv_flow_api.id(16609547294871732)
,p_default_required_label=>wwv_flow_api.id(16609847425871732)
,p_default_page_transition=>'NONE'
,p_default_popup_transition=>'NONE'
,p_default_navbar_list_template=>wwv_flow_api.id(16599475809871723)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#IMAGE_PREFIX#themes/theme_42/1.6/')
,p_files_version=>69
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#',
'#APP_IMAGES#Custom-Template-CSS.css'))
);
wwv_flow_api.component_end;
end;
/
