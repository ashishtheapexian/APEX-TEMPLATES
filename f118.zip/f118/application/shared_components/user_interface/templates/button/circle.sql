prompt --application/shared_components/user_interface/templates/button/circle
begin
--   Manifest
--     BUTTON TEMPLATE: CIRCLE
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>9474325786859224
,p_default_application_id=>118
,p_default_id_offset=>0
,p_default_owner=>'ONTOOR'
);
wwv_flow_api.create_button_templates(
 p_id=>wwv_flow_api.id(16772625266117239)
,p_template_name=>'Circle'
,p_internal_name=>'CIRCLE'
,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<button onclick="#JAVASCRIPT#" class="t-Button--circle #BUTTON_CSS_CLASSES#" type="button" #BUTTON_ATTRIBUTES# id="#BUTTON_ID#"><span class="t-Button-label"><i class="fa #ICON_CSS_CLASSES#"></i></span></button>',
''))
,p_theme_class_id=>1
,p_theme_id=>42
);
wwv_flow_api.component_end;
end;
/
